const express = require('express');
const router = express.Router();
const db = require('../db');  // Conexão com o banco de dados

// Renderizar a página de performance
router.get('/', (req, res) => {
    db.query('SELECT name, performanceRating FROM employees', (err, results) => {
        if (err) {
            return res.status(500).send('Database query error');
        }
        // Renderiza a página de performance com os dados de performance dos funcionários
        res.render('performance', { employees: results });
    });
});

module.exports = router;
