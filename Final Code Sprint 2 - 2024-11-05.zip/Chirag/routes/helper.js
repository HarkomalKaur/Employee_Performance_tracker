const moment = require('moment');


formatMoney = function(value) {
    let formatter = new Intl.NumberFormat('en-US', {style: 'currency', currency: 'USD'});

    return formatter.format(value);
}

formatTime = function (value){
    var date = moment(value).format('MMMM Do YYYY, h:mm:ss a');

    console.log(date);

    return date;
}


// custom middleware to check auth state
function isAuthenticated(req, res, next) {
    if(!req.session){
        return res.redirect('/home'); // redirect to sign-in route
    }

    if (!req.session.isAuthenticated) {
        return res.redirect('/home'); // redirect to sign-in route
    }

    next();
};



module.exports = {
    formatMoney: formatMoney,
    formatTime: formatTime,
    isAuthenticated: isAuthenticated
};