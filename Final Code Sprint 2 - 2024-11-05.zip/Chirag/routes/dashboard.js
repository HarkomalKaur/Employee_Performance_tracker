const express = require('express');
const router = express.Router();
const db = require('../db');  // Importa a conexão com o banco de dados

var helper = require('./helper');

// Sales Page
router.get('/sales',
    helper.isAuthenticated,
    (req, res) => {
    db.query('SELECT * FROM employees', (err, results) => {
        if (err) {
            return res.status(500).send('Database query error');
        }
        // Renderiza a página de vendas com os dados dos funcionários
        res.render('sales', { employees: results, user: req.session.account.name });
    });
});

// Feedback Page
router.get('/feedback',
    helper.isAuthenticated,
    (req, res) => {
    db.query('SELECT * FROM employees', (err, results) => {
        if (err) {
            return res.status(500).send('Database query error');
        }
        // Renderiza a página de feedback com os dados dos funcionários
        res.render('feedback', { employees: results, user: req.session.account.name });
    });
});

router.post('/feedback',
    helper.isAuthenticated,
    (req, res) => {
    const { name, feedback } = req.body;

    // Encontra o funcionário pelo nome
    db.query('SELECT * FROM employees WHERE name = ?', [name], (err, results) => {
        if (err) {
            return res.status(500).send('Database query error');
        }

        if (results.length > 0) {
            // Adiciona o feedback ao funcionário (simulando isso no banco)
            const employee = results[0];
            // Exemplo: Adicionando o feedback em um campo no banco (essa parte depende de como o banco está estruturado)
            db.query('UPDATE employees SET feedback = ? WHERE id = ?', [feedback, employee.id], (err) => {
                if (err) {
                    return res.status(500).send('Error updating feedback');
                }
                // Renderiza a página de feedback com os dados atualizados
                res.redirect('/dashboard/feedback');
            });
        } else {
            res.status(404).send('Employee not found');
        }
    });
});

// Performance Page
router.get('/performance',
    helper.isAuthenticated,
    (req, res) => {
    db.query('SELECT * FROM employees', (err, results) => {
        if (err) {
            return res.status(500).send('Database query error');
        }
        // Renderiza a página de performance com os dados dos funcionários
        res.render('performance', { employees: results, user: req.session.account.name });
    });
});

module.exports = router;
