const express = require('express');
const router = express.Router();
const db = require('../db');  // Conexão com o banco de dados

var helper = require('./helper');

router.get('/',
    helper.isAuthenticated,
    (req, res) => {
        /*
        db.query('SELECT name, performanceRating FROM employees', (err, results) => {
            if (err) {
                console.error('Database query error:', err);
                //return res.status(500).send('Database query error');

                res.render('error/error', { title: 'Database query error', error: err });

            }
        });
         */

        let userInfo = {
            name: req.session.account.name,
            mobile: '(+12) 123 1234 567',
            email: req.session.account.username,
            location: 'USA',
            language: 'English, German, Spanish'
        }

        // Renderiza a página de performance com os dados de performance dos funcionários
        res.render('profile', { user: req.session.account.name, info: userInfo });
    });


module.exports = router;