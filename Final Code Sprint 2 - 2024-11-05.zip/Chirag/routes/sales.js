const express = require('express');
const router = express.Router();
const db = require('../db');  // Conexão com o banco de dados

var helper = require('./helper');

const path = require("path");

// Rota para exibir a página de vendas
router.get('/',
    helper.isAuthenticated,
    (req, res) => {
    const query = `
        SELECT 
            employees.name, 
            employees.profileImage, 
            sales.sale_amount AS actualSales, 
            sales.sale_date AS saleDate
        FROM 
            employees 
        JOIN 
            sales 
        ON 
            employees.id = sales.employee_id
    `;

    db.query(query, (err, results) => {
        if (err) {
            console.error('Database query error:', err);
            return res.status(500).send('Database query error');
        }
        // Renderiza a página de vendas com os dados de vendas dos funcionários
        res.render('sales', { sales: results, user: req.session.account.name });
    });
});

module.exports = router;
