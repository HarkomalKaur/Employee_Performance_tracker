const express = require('express');
const path = require('path');
const db = require('./db');  // Importa a conexão com o banco de dados MySQL
const app = express();

// Configura EJS como o motor de views
app.set('view engine', 'ejs');
app.use(express.urlencoded({ extended: true }));

// Middleware para servir arquivos estáticos (imagens, CSS, etc.)
app.use(express.static(path.join(__dirname, 'public')));

// Rota para a página inicial
app.get('/', (req, res) => {
    res.render('home');
});

// Importa a rota de vendas
const salesRoutes = require('./routes/sales'); // Caminho para o arquivo de rota sales.js
app.use('/dashboard/sales', salesRoutes); // Usa a rota de vendas

// Rota para a página de feedback (dados dinâmicos do MySQL)
app.get('/dashboard/feedback', (req, res) => {
    db.query('SELECT * FROM employees', (err, results) => {
        if (err) {
            console.error('Database query error:', err);
            return res.status(500).send('Database query error');
        }
        // Renderiza a página de feedback com os dados dos funcionários
        res.render('feedback', { employees: results });
    });
});

// Rota para adicionar novo feedback
app.post('/dashboard/feedback', (req, res) => {
    const { name, feedback } = req.body;

    // Busca o funcionário pelo nome
    db.query('SELECT * FROM employees WHERE name = ?', [name], (err, results) => {
        if (err) {
            console.error('Database query error:', err);
            return res.status(500).send('Database query error');
        }

        if (results.length > 0) {
            const employee = results[0];

            // Atualiza o feedback do funcionário
            const updatedFeedback = employee.feedback ? employee.feedback + ',' + feedback : feedback;
            db.query('UPDATE employees SET feedback = ? WHERE id = ?', [updatedFeedback, employee.id], (err) => {
                if (err) {
                    console.error('Error updating feedback:', err);
                    return res.status(500).send('Error updating feedback');
                }
                res.redirect('/dashboard/feedback');
            });
        } else {
            res.status(400).send('Employee not found');
        }
    });
});

// Rota para a página de performance (dados dinâmicos do MySQL)
app.get('/dashboard/performance', (req, res) => {
    db.query('SELECT name, performanceRating FROM employees', (err, results) => {
        if (err) {
            console.error('Database query error:', err);
            return res.status(500).send('Database query error');
        }
        // Renderiza a página de performance com os dados de performance dos funcionários
        res.render('performance', { employees: results });
    });
});

// Rota de teste para verificar a conexão com o banco de dados
app.get('/test-db', (req, res) => {
    db.query('SELECT * FROM employees', (err, results) => {
        if (err) {
            return res.status(500).send('Database query error: ' + err.message);
        }
        res.json(results); // Retorna os dados como JSON para facilitar o teste
    });
});

// Inicia o servidor na porta 3000
app.listen(3000, () => {
    console.log('Server running on port 3000');
});
