const express = require('express');
const router = express.Router();
const db = require('../db');  // Conexão com o banco de dados

// Rota para exibir a página de feedback
router.get('/', (req, res) => {
    db.query('SELECT * FROM employees', (err, results) => {
        if (err) {
            return res.status(500).send('Database query error');
        }
        // Renderiza a página de feedback com os dados dos funcionários
        res.render('feedback', { employees: results });
    });
});

// Rota para processar o envio de feedbacks
router.post('/', (req, res) => {
    const { name, feedback } = req.body;

    // Encontra o funcionário pelo nome no banco de dados
    db.query('SELECT * FROM employees WHERE name = ?', [name], (err, results) => {
        if (err) {
            return res.status(500).send('Database query error');
        }

        if (results.length > 0) {
            const employee = results[0];
            // Exemplo: Adiciona o feedback ao funcionário (ajuste a query dependendo de como o feedback é armazenado no banco)
            db.query('UPDATE employees SET feedback = ? WHERE id = ?', [feedback, employee.id], (err) => {
                if (err) {
                    return res.status(500).send('Error updating feedback');
                }
                res.redirect('/feedback');
            });
        } else {
            res.status(400).send('Employee not found');
        }
    });
});

module.exports = router;
